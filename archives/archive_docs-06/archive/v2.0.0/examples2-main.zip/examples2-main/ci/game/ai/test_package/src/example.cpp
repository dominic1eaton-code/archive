#include "ai.h"

int main() {
    ai();
}
