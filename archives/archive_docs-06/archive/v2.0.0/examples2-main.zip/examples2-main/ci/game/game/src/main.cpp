#include "game.h"

int main() {
    game();
}
