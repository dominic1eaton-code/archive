#include "mapviewer.h"

int main() {
    mapviewer();
}
