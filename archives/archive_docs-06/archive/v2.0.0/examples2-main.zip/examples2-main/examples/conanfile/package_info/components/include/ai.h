void ai();
