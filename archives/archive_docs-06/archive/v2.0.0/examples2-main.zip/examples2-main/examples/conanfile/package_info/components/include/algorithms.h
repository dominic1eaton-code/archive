void algorithms();
