#include <iostream>

#include "algorithms.h"

void ai(){
    std::cout << "I am the ai component!\n";
    algorithms();
}
