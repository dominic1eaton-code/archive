#include <iostream>

void algorithms(){
    std::cout << "I am the algorithms component!\n";
}
