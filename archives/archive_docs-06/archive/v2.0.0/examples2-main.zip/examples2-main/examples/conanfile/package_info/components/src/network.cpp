#include <iostream>

void network(){
    std::cout << "I am the network component!\n";
}
