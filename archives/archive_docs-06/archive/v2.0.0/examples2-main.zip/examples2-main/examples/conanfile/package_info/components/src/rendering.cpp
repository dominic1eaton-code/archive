#include <iostream>

#include "algorithms.h"

void rendering(){
    std::cout << "I am the rendering component!\n";
    algorithms();
}
