#include "algorithms.h"
#include "network.h"
#include "ai.h"
#include "rendering.h"

int main() {
    algorithms();
    network();
    ai();
    rendering();
}
