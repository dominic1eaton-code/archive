## Configuration files examples

### [Use settings_user.yml](settings_user/)

- Learn how to customize your settings thanks to the _settings_user.yml_ file. [Docs](https://docs.conan.io/2/reference/config_files/settings.html#settings-user-yml)
