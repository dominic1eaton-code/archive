#include <cstdlib>
#include <iostream>

int main()
{
    std::cout << "hello world!\n";
    return EXIT_SUCCESS;
}
