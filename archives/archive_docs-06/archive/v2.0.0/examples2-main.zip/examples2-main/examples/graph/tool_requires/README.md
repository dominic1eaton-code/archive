# Conan tool_requires examples

### [Using 2 different versions of the same tool-require in the same consumer package](different_versions)

### [Using the same version of the same tool-require with different options in the same consumer package](different_options)

### [Using protobuf as a normal requirement and as a tool-requirement in your library and consuming it later](using_protobuf)
