# An introduction to the Dear ImGui library

![An introduction to the Dear ImGui library](assets/conan-imgui-widgets.gif)

## Walkthough
This example has a [blog post](https://blog.conan.io/2019/06/26/An-introduction-to-the-Dear-ImGui-library.html).
