# Example using libcurl to download an image and generate some colored ASCII art reading it with stb and printing with fmt

This example is used in the Conan 2.X Visual Studio extension blogpost: https://blog.conan.io/