# Example using libcurl to download an image and generate some ASCII art reading it with stb

This example is used in the Conan 2.X CLion plugin blogpost: https://blog.conan.io/introducing-new-conan-clion-plugin/