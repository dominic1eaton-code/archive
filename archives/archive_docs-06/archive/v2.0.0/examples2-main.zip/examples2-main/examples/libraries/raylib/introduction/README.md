# Example using raylib to create a game

Example for using [raylib](https://www.raylib.com/) to create a simple runner game.