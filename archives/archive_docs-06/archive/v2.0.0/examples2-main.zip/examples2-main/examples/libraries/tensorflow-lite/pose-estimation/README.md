# Video pose detection using TensorFlow Lite and OpenCV

![Output example](assets/output.gif)
