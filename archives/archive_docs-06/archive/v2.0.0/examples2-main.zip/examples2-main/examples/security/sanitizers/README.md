# Using Compiler Sanitizers with Conan

This example follows the documented page https://docs.conan.io/2/examples/security/sanitizers.html about using compiler sanitizers with Conan.

For more information, please refer to the [C, C++ Compiler Sanitizers¶](https://docs.conan.io/2/security/sanitizers.html) documentation page.