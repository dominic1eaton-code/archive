#include "foo.h"

int main() {
    foo();
}
