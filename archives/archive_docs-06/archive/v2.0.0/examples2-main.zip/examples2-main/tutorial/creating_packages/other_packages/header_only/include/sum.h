
inline int sum(int a, int b){
    return a + b;
}
