#include "sum.h"
#include <iostream>

int main() {
    std::cout << "1 + 3 = " << sum(1, 3) << std::endl;
    return 0;
}
