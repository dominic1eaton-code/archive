#include <iostream>
#include <string>
#include "secure_scanner.h"

int secure_scanner(std::string &path){
    std::cout << "Security Scanner: The path '" + path + "' is secure!\n";
    return 0;
}
