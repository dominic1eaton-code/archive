from conan import ConanFile


class Matrix(ConanFile):
    name = "matrix"

