from conan import ConanFile


class Sound32(ConanFile):
    name = "sound32"

