package com.github.bazelbuild.rulesjvmexternal.example.export

/**
 * A simple kotlin test class.
 */
fun main() {
  println("Hello, World!")
}
