package com.example.bazel;

class Main {}
