# Scala Example

To build the Scala application:

```
$ bazel build app
```

To run the Scala application:

```
$ bazel run app
```

To run the tests:

```
$ bazel test test
```
