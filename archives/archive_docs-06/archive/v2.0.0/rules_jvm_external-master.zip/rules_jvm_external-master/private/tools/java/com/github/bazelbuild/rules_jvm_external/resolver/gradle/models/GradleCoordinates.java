// Copyright 2025 The Bazel Authors. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.github.bazelbuild.rules_jvm_external.resolver.gradle.models;

/**
 * GradleCoordinates models the coordinates representation of Coordinates in build.gradle. Similar
 * to the existing Coordinates class in rules_jvm_external, but we need to use interfaces to work
 * with Gradle Tooling Model builder.
 */
public interface GradleCoordinates {
  String getGroupId();

  String getArtifactId();

  String getVersion();

  String getClassifier();

  String getExtension();
}
