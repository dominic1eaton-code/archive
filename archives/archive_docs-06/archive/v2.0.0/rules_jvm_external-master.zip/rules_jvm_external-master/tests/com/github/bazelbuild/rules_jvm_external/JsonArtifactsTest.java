package com.github.bazelbuild.rules_jvm_external;

import org.junit.Test;

public class JsonArtifactsTest {

  /* No-op test to ensure that the JSON artifact is not included
   * in the "deps" attribute of the auto-generated jvm_import rule.
   */
  @Test
  public void test_noop() {}
}
