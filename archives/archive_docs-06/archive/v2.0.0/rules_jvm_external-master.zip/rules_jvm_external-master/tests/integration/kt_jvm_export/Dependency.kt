package com.jvm.external.jvm_export

class Dependency {
    fun getName(): String {
        return "kt_jvm_export test"
    }
}
