package com.jvm.external.jvm_export

fun main() {
    println("Name is: " + Dependency().getName())
}
