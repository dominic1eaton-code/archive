package com.github.bazelbuild.rules_jvm_external.example.maven_bom;

public class TwoDeps {
  // This space left blank intentionally
}
