class ClassUsingClassUsingAnnotationProcessor {
  public void exercise() {
    System.out.println(ClassUsingAnnotationProcessor.create("hello").field());
  }
}
