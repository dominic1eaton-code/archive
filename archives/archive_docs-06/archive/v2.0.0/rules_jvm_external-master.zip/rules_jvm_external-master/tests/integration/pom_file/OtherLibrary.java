package tests.integration.pom_file;

public class OtherLibrary {}
