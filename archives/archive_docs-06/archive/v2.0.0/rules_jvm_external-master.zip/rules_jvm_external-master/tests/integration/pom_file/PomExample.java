package tests.integration.pom_file;

public class PomExample {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
