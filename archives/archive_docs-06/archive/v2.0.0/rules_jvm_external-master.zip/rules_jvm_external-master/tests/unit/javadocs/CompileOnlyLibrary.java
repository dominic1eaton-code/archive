package unit.javadocs;

import com.squareup.javapoet.*;

public class CompileOnlyLibrary {
  public CompileOnlyLibrary() {}
}
