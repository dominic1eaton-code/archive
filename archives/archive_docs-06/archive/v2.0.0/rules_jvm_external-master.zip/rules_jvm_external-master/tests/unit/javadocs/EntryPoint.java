package unit.javadocs;

public class EntryPoint {
  public static void main(String[] args) throws Exception {
    System.out.println("Hello World!");
  }
}
