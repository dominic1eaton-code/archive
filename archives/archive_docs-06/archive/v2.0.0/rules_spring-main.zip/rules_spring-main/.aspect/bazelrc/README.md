## Aspect bazelrc Presets

See:
- [Aspect Presets](https://github.com/bazel-contrib/bazel-lib/tree/main/.aspect/bazelrc)