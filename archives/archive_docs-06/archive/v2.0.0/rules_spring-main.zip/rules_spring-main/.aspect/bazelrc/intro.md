# Aspect bazelrc presets

The `.bazelrc` files found here are the source-of-truth for our recommended Bazel presets.

They are mirrored on our docsite at https://docs.aspect.build/guides/bazelrc.
