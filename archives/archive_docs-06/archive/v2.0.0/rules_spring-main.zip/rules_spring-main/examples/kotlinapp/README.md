## Kotlin Example for Bazel Spring Boot

To avoid cluttering the WORKSPACE file for everyone, the Kotlin example is published
  in a dedicated branch of this repository.

- [KotlinApp](https://github.com/salesforce/rules_spring/tree/examples_kotlin) shows how to build and run  Spring Boot applications written in Kotlin with *rules_spring*
