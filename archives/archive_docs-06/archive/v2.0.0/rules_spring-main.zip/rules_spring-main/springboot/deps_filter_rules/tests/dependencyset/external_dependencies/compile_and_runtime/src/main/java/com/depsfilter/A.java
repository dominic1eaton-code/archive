package com.depsfilter;

public class A {
    int a;
    public A() {
        a = 1;
    }
}