package com.depsfilter;

public class B {
    private C c;
    public B() {
        c = new C();
    }
}