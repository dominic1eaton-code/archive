package com.depsfilter;

public class C {
    // D is a runtime dependency, so no compile-time reference here
    public C() {
        // No compile-time dependencies
    }
}