package com.depsfilter;

public class D {
    private int value;
    public D() {
        value = 4;
    }
} 