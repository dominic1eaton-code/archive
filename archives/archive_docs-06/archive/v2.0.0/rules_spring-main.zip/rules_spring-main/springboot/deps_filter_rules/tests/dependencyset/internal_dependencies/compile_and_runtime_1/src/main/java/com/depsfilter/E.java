package com.depsfilter;

public class E {
    private F f;
    public E() {
        f = new F();
    }
} 