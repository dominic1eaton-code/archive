package com.depsfilter;

public class F {
    private C c;
    public F() {
        c = new C();
    }
} 