package com.depsfilter;

public class G {
    private F f;
    public G() {
        f = new F();
    }
} 