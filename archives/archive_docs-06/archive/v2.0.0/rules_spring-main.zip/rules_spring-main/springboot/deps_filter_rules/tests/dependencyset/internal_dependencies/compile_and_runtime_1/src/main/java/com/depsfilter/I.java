package com.depsfilter;

public class I {
    public I() {
        int i = 1;
    }
} 