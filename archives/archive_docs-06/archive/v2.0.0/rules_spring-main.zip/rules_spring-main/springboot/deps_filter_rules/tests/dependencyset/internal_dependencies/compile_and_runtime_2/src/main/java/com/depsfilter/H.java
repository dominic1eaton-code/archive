package com.depsfilter;

public class H {
    public H() {
        int h = 1;
    }
} 