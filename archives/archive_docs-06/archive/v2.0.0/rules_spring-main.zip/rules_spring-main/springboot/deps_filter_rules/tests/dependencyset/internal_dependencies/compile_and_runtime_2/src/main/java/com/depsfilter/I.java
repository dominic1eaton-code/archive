package com.depsfilter;

public class I {
    private F;
    public I() {
        F = new F();
    }
} 