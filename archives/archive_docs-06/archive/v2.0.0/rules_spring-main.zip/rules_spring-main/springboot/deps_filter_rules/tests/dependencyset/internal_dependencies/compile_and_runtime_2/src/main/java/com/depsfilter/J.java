package com.depsfilter;

public class J {
    private B b;
    public J() {
        b = new B();
    }
} 