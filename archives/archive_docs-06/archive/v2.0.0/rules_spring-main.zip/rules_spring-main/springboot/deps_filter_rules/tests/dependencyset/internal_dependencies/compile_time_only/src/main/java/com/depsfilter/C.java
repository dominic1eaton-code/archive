package com.depsfilter;

public class C {
    private D d;
    public C() {
        d = new D();
    }
}