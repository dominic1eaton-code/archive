package com.depsfilter;

public class H {
    private A a;
    private I i;
    public H() {
        a = new A();
        i = new I();
    }
} 