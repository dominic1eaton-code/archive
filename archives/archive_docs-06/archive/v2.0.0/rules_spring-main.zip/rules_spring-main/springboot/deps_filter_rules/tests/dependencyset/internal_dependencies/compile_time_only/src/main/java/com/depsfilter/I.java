package com.depsfilter;

public class I {
    private G g;
    public I() {
        g = new G();
    }
} 