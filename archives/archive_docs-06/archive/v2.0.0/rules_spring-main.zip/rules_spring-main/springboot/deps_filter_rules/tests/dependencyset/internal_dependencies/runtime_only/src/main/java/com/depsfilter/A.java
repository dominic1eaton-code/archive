package com.depsfilter;

public class A {
    public A() {
        int a = 1;
    }
}