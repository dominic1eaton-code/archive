package com.depsfilter;

public class B {
    public B() {
        int b = 1;
    }
}