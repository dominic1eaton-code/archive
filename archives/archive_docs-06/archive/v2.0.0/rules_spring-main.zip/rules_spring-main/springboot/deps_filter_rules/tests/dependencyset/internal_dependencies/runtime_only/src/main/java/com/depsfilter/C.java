package com.depsfilter;

public class C {
    public C() {
        int c = 1;
    }
}