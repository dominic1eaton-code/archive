package com.depsfilter;

public class D {
    public D() {
        int d = 1;
    }
} 