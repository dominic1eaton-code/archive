package com.depsfilter;

public class E {
    public E() {
        int e = 1;
    }
} 