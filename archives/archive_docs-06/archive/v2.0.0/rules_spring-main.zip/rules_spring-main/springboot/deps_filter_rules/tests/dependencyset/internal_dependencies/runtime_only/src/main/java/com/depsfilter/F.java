package com.depsfilter;

public class F {
    public F() {
        int f = 1;
    }
} 