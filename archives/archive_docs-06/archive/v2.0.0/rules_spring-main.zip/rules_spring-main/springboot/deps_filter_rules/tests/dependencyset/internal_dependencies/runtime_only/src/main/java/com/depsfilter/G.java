package com.depsfilter;

public class G {
    public G() {
        int g = 1;
    }
} 