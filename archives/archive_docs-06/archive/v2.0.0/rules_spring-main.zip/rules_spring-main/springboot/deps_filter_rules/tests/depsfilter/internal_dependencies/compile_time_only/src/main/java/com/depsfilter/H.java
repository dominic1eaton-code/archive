package com.depsfilter;

public class H {
    private A a;
    private G g;
    public H() {
        a = new A();
        g = new G();
    }
} 