## Springboot() Attributes

This page has moved [here](attributes.bzl).