package com.salesforce.rulesspring.index;

public enum IndexFileType {
    LIBRARY, // jar file
    CLASS, // .class file
    RESOURCE // anything else
}
