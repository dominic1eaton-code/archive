package com.salesforce.rulesspring.index;

public class SpringBootJarIndexerTest {

}
