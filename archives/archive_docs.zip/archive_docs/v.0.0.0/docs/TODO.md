# ume-os
[ ] organization operating system
    [ ] ume kernel
    [ ] umuthi ERP system
    [ ] esu module, integration system
    [ ] jini operations app
    [ ] pamoja HRM app
    [ ] moto work management app
    [ ] shango CRM app
    [ ] chombo EMS app
    [ ] amanzi finance, accounting app
    [ ] akili management, governance app
    [ ] mikono PLM, product management, development and design app
    [ ] taarifa KMS app
    [ ] yemaya CSR, sustainability app
    [ ] erinle design system app
    [ ] mila time, schedule management app
    [ ] kupewa data management app
    [ ] olumo system management, administration app
    [ ] jiwe physical infrastructure management, administration app
    [ ] kujali security, privacy platform app
    [ ] iso front end client

# qala-SF
[ ] software factory
    [ ] package manager
    [ ] software product/solution/application release configuration manager
    [ ] software PLM, release deployment management system
    [ ] sandbox developer cli, management system
    [ ] automated build system
    [ ] automated testing environment
    [ ] automated QA environment
    [ ] IaC system, system configuration manager
    [ ] project/solution/software product development IDE, SDE

# ochosi-sde
[ ] software/simulation development environment
    [ ] ogun-sdk simulation/engine development kit
    [ ] eto editor
    [ ] oru game engine
    [ ] elegua FEA engine
    [ ] yewa CAD engine
    [ ] dada CAM engine
    [ ] aroni DES engine
    [ ] yota simulation engine
    [ ] iroko BIM engine

# nuru
[ ] wakati e-community, e-governance app
[ ] impande resource sharing platform

# dedun 
[ ] dagba-kazi gig, contracter management app
[ ] dewo app, VoIP, messenger, intranet, email, chat(room)
[ ] dongo, dongo-air airtime currency mobile payment system, digital wallet

# nandi
[ ] mobility platform
    [ ] EV passenger sedan build
    [ ] EV passenger truck build
    [ ] EV commercial van build
    [ ] EV passenger bus build

# imewe
[ ] digital fabrication platform
    [ ] 3D filament small form factor unenclosed printer
    [ ] 3D filament medium form factor enclosed printer
    [ ] 3D filament large form factor unenclosed printer
    [ ] 3D filament large form factor enclosed printer
    [ ] 3D resin medium form factor enclosed printer

# mizizi-miji
[ ] urban development management system platform