# 
technology platform

# niguvu
governance

## batwa
management

## kanye
fund

## obatala
makerspace, VC studio, accelerator, incubator

### emchoro
* cheche
* cheneo
* moyo
* nandi
* oniru
* ossain

### jumuiya
* khoi
* herero
* nama
* aka
* igbo


