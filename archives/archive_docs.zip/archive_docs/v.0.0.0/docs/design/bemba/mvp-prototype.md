# prototype MVPs
minimal viable product prototypes list
firm list

## bemba technologies
technology firm
operating company
decentralized HQ

# niguvu
governance firm
holding company

### obatala
VC studio, makerspace firm, fablab

### batwa
management firm

### kanye
fund firm

### D.E. LLC
software, technology consulting

