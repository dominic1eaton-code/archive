#
VC studio, makerspace firm, fablab


# makerspace
collaborative creation space

- crafts, electronics, collab space share
- prototyping equipment
- DIY projects
- woodshop
- textile shop
- art projects

## hackerspace
NPO, community operated creation space, electronic/digital makerspace
* technology projects
* science projects
* digital art

## fablab
* chartered organization, foundation governance

- digital fabricatino, "make anything anywhere" paragidm
- 3d printingv, laser cutting, CNC machine, electronics equipment
- standardized creation, prototyping factory



# coworking space
shared working environment



# VC studio
business factory

## accelerator
intensive later firm rapid growth support services

## incubator
early firm support services

## VC fund
prviate equity investment fund


