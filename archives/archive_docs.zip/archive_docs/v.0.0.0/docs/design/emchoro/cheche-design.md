#
ecosystem services
ecosystem as a service
energy Efficiency as a Service (EaaS):
Heating and Cooling as a Service (HaaS/CaaS)
eco-studio

notes:
- Energy Service Agreements (ESAs): 
- eco services, ciruclar economy, upcycling
- solar as a service


# ifufe
autonomous energy systems
heating, cooling, power

# osisi
automated plant propogation platform

# ashe
terraformata platform
autonomous ecoservices
green space services
