# overview
space as a service
leasing as a service
housing as a service
real estate as a service
real estate studio
space sharing service firm

# cheneo-rer (real estate reuse)
* commercial space reuse program
* space management system 
* real estate managementn system
* property management system

insurance
housing policy management
housing rating
eligibility process
housing services
funding sources
rental, leasing, space resources
housing, space fund supplements, payment models

easement agreement


- spacebring
- wework
- spark stl
- lobbytrack
- liquidspace
- regus
- eventbrite
- meetup
- neighbor


space sharing
makerspace
warehouse sharing
coworking space
storage, parking market place


# space sharing platform, build v1.0.0
*simplify the use, reuse of space*

- platform services
compliance, regulation, entity management system
housing, space policy management system
insurance management system
building, facilities management system
    find government land, LRA programs land and property search/management/administration services
    regulation, rezoning, compliance services
real-estate, property, land management system
buyer, seller, leaser, renter, leasee, rentee management system, incentive mechanism desigm module



* residential
    * roommate finder, matcher

    * rent, (sub)lease, home finder, matcher

    * unhoused, homeless shelter management system, finder, matcher

    * co-living, communal living spaces

* commercial

    * office space share finder, matcher, manager, administration

        * entreprenuer, start-up office space, shared coworking spaces

        * service industry shared work spaces

            * barber, beautyshop shared spaces finder, matching, management, administration

            * local home goods, food store, living items store

            * local clothing, textiles shops

            * etc...

* industrial

    * warehouse share finder, matcher, manager, administration
        * inventory, asset, capital management system
