# prototype MVPs
minimal viable product prototypes list
firm list


# moyo
digital business platform firm

## ume
digital organization platform
ERP system



# ossain
simulation, software firm
gaming, simulation platform
platform, environment, ecosystem as a service platform

## oru
game engine
simulation platform ## yota

## qala
SDE, IDE, software factory



# oniru
production as a service platform firm

## imewe
3d printer system
3D printing vehicle platform
vehicle build
carbon fiber reinforced polycarbonate (PC-CF) automotive body panel printing
CNC machine, printing


# nandi
mobility firm
mobility platform



## nandi-ev

* electric ground mobilty fleet

    * electric commercial vehicle fleet

        * electric commercial taxi

        * electric commercial van

        * electric commercial bus

        * electric commercial truck
        
        * electric commercial locomotive

    * electric passenger vehicle fleet

        * electric passenger sedan
        
        * electric passenger truck

        * electric passenger motorcycle

## amaya
VANET terrestrial network platform


# cheneo
space sharing, reuse firm
space sharing platform



# cheche
ecosystem service firm
ecosystem service platform


