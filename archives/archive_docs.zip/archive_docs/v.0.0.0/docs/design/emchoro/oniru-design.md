# overview
production, manufacturing as a service
fabrication studio


# imewe
- autonomous fabrication

## 3d printer build v1.0.0
* X-Y-Z axis motors
* end stops, limit switches
* print bed
    * bed surface
* 3d printer controller, motherboard, GCode executor
    * SD card slot, GCode file loader
    * motor stepper drivers
* extruder
    * extruder motor
* bowden tube
    * bowden style extruder
* hotend
    * nozzle
    * heater block
    * heater cartridge
    * thermistor
    * heat break, heat sink
    * cooling fan
    * part cooling fan
* printing material, filament
    * polycarbonate
* sensors
    * auto level sensor
    * filament sesnor
* frame, enclosure
* electrical systems
    * power sypply
* UI
    * UI screen device, touch display driver 
    * printer I/O, user input HID, HUD, HMI device module
        * settings adjustor
        * info viewer, model viewer
* impact analysis

# kituo
- autonomous factory
