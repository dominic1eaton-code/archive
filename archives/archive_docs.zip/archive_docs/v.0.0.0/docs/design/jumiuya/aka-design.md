# overview
community center network program 
environment program

- community development, renovation program
- eco-development program, greenspace program

# decentralized community center program
* independant operating units, NPO franchise
* programming
    * financial programming
    * eco-development, eco-services programming
    * medical, mental health, health, food, veganism programming
    * social services programming
    * extra-cirricular programming
    * misc. programming


# reparations program
compensation
restituion
rehabiliation
satisfaction
guareuntees of non repittion


# existing infrastructure integration program
* medical, clinical infrastructure integration
* existing diversity, community, environment programs integration
* community forestry, eco-projects
* community vegan, food projects
* community partnerships programming

