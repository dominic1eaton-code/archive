# 
financial program
Freedman's Savings and Trust Company LLC
credit union
investment fund, reparations relief fund
asset, portfolio, investment management program
decentralized credit union system
community bank program

