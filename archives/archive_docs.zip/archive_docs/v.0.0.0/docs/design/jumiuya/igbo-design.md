#
- memorial, monument, museum greenspace program


* monuments to the enslaved + greenspace program
* american history museum program
* memorial programs


* memorial-greenspace programs
    * statues program
        * statue manufacturing program, bronze-marble-granite
        * statues of the fallen
        * statues of historical figures
    * museums program
    * walls of the Maafa (enslaved peoples) program
        * https://www.slavevoyages.org/past/database
        * walls of the Maafa
    * memorial sites - greenspace progrm
        * Maafa memorial program
        * clotilda site
        * igbos landing site
        * emmit till site
        * attica prison riot memorial (ghosts of attica)
        * BLM memorial sites
        * prison memorial sites
        * tulsa memorial
        * etc...

