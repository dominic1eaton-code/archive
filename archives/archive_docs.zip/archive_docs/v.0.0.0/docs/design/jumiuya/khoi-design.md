# overview
housing, living essentials program

housing as a service
real estate as a service

- housing program
    * housing renovation program
    * housing-work-learn/vocation program