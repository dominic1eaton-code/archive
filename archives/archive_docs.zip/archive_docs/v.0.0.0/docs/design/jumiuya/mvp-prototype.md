# prototype MVPs
minimal viable product prototypes list
firm list


