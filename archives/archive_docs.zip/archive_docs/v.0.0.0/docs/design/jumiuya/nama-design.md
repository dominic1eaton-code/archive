# overview
work, learning, talent generation program, education/training program   
entreprenuership program, LLC establishment, investments/portfolio management program

- work, job program
    - vocation program
        * construction
    - professional services program
        * law
        * medicine
        * engineering
    - stem program
         * science
         * programming, technology
    - non stem program
        * business, administration
        * accounting

entreprenuership, business studio, accelerator, incubator program
- obatala

