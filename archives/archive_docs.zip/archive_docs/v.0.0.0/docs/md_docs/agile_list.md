# manual agile items list

# Groups
G-000001 Akili Group

# Firms
F-000001 Ossain Games Studio

# Metrics

# Strategies

# Functions

    # Management

    # Administration

    # Operations

    # Software, Technology

    # Finance, Accounting

    # IT

    # Office, Infrastructure

    # HR

    # Marketing

    # Security, Privacy

    # Legal


# Organizations
O-000001
    # Employees

    # Divisions

    # Departments

    # Teams
    TM-000001 Boostrapping Team

        # Squads

        # Chapters

        # Guilds

        # Tribes

    # Units
        # Squads

        # Platoons

        # Troops

        # Battalion

        # Brigade

        # Division

        # Corps

        # Armies


# Portfolios
PO-000001 Oru Platform

    # Programs
    PG-000001 Oru Game Engine

        # Projects
        PJ-000001 Ogun Renderer Kernel

        # Timeboxes
    
            # Milestones

            # Goals

            # Objectives

            # PI

                # sprint

            # Releases
            R-000001

        # Solutions

        # themes
        TH-000001 Digital Gaming
        Develop Game Engine and produce games

            # initiatives
            I-000001 Ogun Render Engine Kernel Development
            Create render Engine

                # epics
                E-000001 Ogun Kernel
                develop kernel engine

                # issues

                    # stories

                        # features
                        F-000001 Basic Render Kernel Model
                        create initial ogun renderer vulkan kernel model

                        F-000002 Kernel Model unit tests
                        create unit tests

                        F-000003 Basic GUI Kernel Model

                        F-000004 dynamically updating index, vertex and storage buffers
                        update model matrix (rotation, translation, scale) of objects in scene based on user input

                        F-000005 object selection mechanism
                        highlight/outline object when cursor passes over fragment in window

                        F-000006 .obj and .mtl object file parsing

                        F-000007 Text Renderer

                        F-000008 Skybox

                        F-000009 Terrain and Tesselation shader processing
                  
                        # bugs
                        B-000001

                        # defects
                        D-000001

                        # enhancements
                        EH-000001

                        # tests
                        T-000001

                            # tasks

                    # blocker


                    # enabler


                    # capabilities
                    C-000001


                    # requirements
                    RE-000001 

                    # risks
                    RK-000001


# Firms
F-000002 Moyo Studio
Enterprise Technologies

# Portfolios
PO-000002 Kituo Platform
Kituo Infrastructure Platform

    # Programs
    PG-000002

        # Projects
        PJ-000002 Apata Database App Kernel

        # themes
        TH-000002 Database Infrastructure

            # initiatives
            I-000002

                # epics
                E-000001 Apata Kernel
                develop kernel app

                # issues

                    # stories

                        # features
                        F-000010 Basic Database Kernel Model

