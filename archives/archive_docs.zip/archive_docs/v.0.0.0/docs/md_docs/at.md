# Agent theory

amdhals law
conways law
brooks law

dunbars number

information entropy
social entropy


general agent system
- limit of architecture/design, process from communication entropy/interaction between multiple agents
- agent boundary, agent boundary communication/interaction entropy (cost) and agent replication (structure generation)
- enterprise org chart/architecture matches/homomorphic to produced solution/product design
- low cost within boundaries, high cost outside of boundaries, agent boundary information communication (memetics) cost

observation
- design from previous org chart in all current/future org charts (markov chain, random process) as org chart evolves with evolving product
    - creation of new org with new product, no history, provenance removal
    - org chart superposition principle
    - org system scale, dimensions
        - temporal scale, dimension
        - spatial scale, dimension
- infinite cost between agent boundary on temporal dimension (no time travel communication)

solution design space, org chart development

pareto optimiality, genetic algorithm, nash equilibrium

agent filter mechanism
agent generation exploration mechanism



* https://www.youtube.com/watch?v=5IUj1EZwpJY




- scale invariant agent system mechanics, dynamics
- agent system conservation and equilibrium
- agent system boundary replication, conways law

