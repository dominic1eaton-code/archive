# design
VC studio system

# business studio management system API
create firm <name>

    update firm

    delete firm

    read firm

    list firms

    search firm
    
    create entity

        create contract

    create portfolio <name>

        add product

        add solution

create workspace

    create document

        create sheet

        create form

        create table

        create notes

    add document



