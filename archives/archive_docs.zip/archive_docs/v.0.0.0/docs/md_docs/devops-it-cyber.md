# devops
- gitlab administration
- gitlab project,workspace management


* devops organization
    - https://about.gitlab.com/blog/2022/03/08/key-organizational-models-for-devops-teams/
    * devops as a service; devops helpdesk,ticket management
    * devops infrastructure consulting
    * devops automation environment and tools development,maintainence,management
    * Chief Technology Officer
    * devops engineer
    * devops architect,designer
    * devops analyst
    * release manager, PLM
    * devops site reliability engineer
    - devops helpdesk


# IT
* IT organization
    * IT as a service; IT helpdesk,ticket management
    - system administration
    - IT procurement
    - IT database,network,infrastructure management
    - IT business intelligence
    * IT support specialist
    * network and system administrator
    * IT developer
    * IT architect,designer,strategist
    * IT business analyst
    * IT project manager
    * IT trainer
    * IT director
    * IT operations manager
    * IT helpdesk, support team
    * database adminstrator
    * network manager
    * IT enterprise architect
    * IT complaince manager
    * IT innovation manager
    * IT QA director,manager,specialist,analyst
    * Chief Information Officer
    * NoC
        * NoC manager
        * NoC analyst
        * NoC technician 
        * NoC engineer
        - data traffic, incident report,response,escalation manamagent
        - network monitoring
        - network infrastructure management
        - physical access control
        - network assurance, auditing
        - backup, disaster recovery
        - network, systems permsissions management
        - IT helpdesk

# cyber
* cybersecurity organization
    * department, team
        * chief information security officer CISO
        * SoC,security analyst
        * security and compliance officer
        * security engineer
        * security manager
        * security awareness trainer
        * penetration tester
        * security architect,designer
        * security auditor
        * incident report,response,triage team
        - GRC, compliance, regulation management
        - information risk council
        - cybersecurity framework
        - security policies,standards
        - incident response and management
        - security training
        - network security
        - endpoint protection
        - identity and access management,control; permsissions management
        - data encryption
        - security monitoring
        - security helpdesk
    * SoC
        * SEIM
            * cybersecurity as a service; cybersecurity helpdesk,ticket and event management; security threat triage service
            * administration
            * design, architecture

# procurement department; purchasing and sales
- purchasing,procurement policy management
- purchase order management
- mointoring deliveries, schedules, invoices
* software procurement, purchasing
    - sourcing, evaluating vendors/suppliers
    - software contract negotation
    - software supplier relations
    - software compliance management
    - software licensing management
    