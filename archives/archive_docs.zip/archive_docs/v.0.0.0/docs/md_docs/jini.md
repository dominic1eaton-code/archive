# operations
- operating margin
- EBIDTA
- COGS cost of goods sold


https://www.procuredesk.com/procurement-department/