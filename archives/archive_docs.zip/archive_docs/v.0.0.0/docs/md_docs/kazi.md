# digital labor platform
* digital labor (social) network platform   
    - the "facebook,linkdin,social media + fiver,upwork,airbnb + jira,monday,asana etc..." for digital labor
    - project based labor management system
    - personal,grassroots project management system
        - personal project portfolio showcase
    - user social media, personal communications, email management
    - user schedule,task,work,calender management


* digital labor management system
    - digital labor marketplace platform
    - digital labor financial management system
    - digital labor work,schedule,task management system
    - digital labor event management system


* user sample project management e.g.'s
    - call for project members
    - project proposal page
    - project funding page
    - project lifecycle, distribution management
    - personal user,team,organization (personal,contracting,gig,etc...)project portfolio management
    * grass roots volunteer project
        * call for volunteers
    * small team AAA video game development project,team
        * call for video game development team
        * gig,contracter,freelancer labor market
            * video game developer freelancer
                * github project profile
            * music freelancer
                * reddit post freelancer finding
                * spotify,youtube music samples profile
            * writing freelancer
                * writing samples profile
            * artist freelancer
                * art samples profile
            * voice (artist) freelance
                * podcasting profile
                * voice samples
