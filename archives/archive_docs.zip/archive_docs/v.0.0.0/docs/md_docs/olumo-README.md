# iT, server management


## server management and admin
* CRUD network
    * CRUD server
* view network
    * view network performance
        * throughput, latency, MTU
        * 
* view servers
    * find server
    * view server info
    * view server performance
        * throughput
        * latency
        * speed
        * clock cycles
        * hardware performance
        * software performance


