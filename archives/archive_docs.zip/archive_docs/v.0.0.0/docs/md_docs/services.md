# services list
technology as a service
software as a service
business as a service
mobility as a service
platform as a service
infrastructure as a service
space as a service
community development, opportunity as a service
production as a service




# niguvu HoldCo
board, governance company

## kanye FundCo
VC, private equity fund

## obatalaX OpCo
business studio/factory/platform


### emchoro IncentiveCo
software technology company

### emchoro PortCo
software technology company

#### moyo
business as a service

#### nandi
mobility as a service

#### cheneo
space as a service

#### ossain
games/simulation as a service
- oru game engine
- yota sim engine

#### oniru
platform as a service
infrastructure as a service
- SDE
- software factory

#### nyuki
production, manufacturing as a service
- imewe autonomous fabrication


### jumuiya IncentiveCo
NPO community development

### jumuiya PortCo
NPO community development

- housing program
    * housing renovation program
    * housing-work-learn/vocation program
- mental health, health program
- work, job program
    - vocation program
        * construction
    - professional services program
        * law
        * medicine
        * engineering
    - stem program
         * science
         * programming, technology
    - non stem program
        * business, administration
        * accounting
- community development program
- eco-development program, greenspace program
- memorial, monument, museum program

#### herero

#### nama

#### aka

#### khoi

#### igbo

