#
office tools
digital workspace
document/content creation and management system
communications, chat, email platform
event management system

## digital workspace
- google drive


## communications platform
* application
    * broadcast, multicast, unicast chat 
        * web, mobile, desktop
    * settings
        * profile settings
        * appearance settinsg
    * select, deselect elements, emails, chats
    * search email, chats
    * add-ons, extensions
        * calendar
        * contact
        * task manager, schedule
* chat platform
* email platform
    * email server
    * email client
        * web, mobile, desktop
        * send/recieve email
            * inbox, spam, flagged (starred), filter, sent, drafts, trash, severity, labels, categories
            * email editing
            * encryption
            * digital signature signing
            * attachments


## event management system
* create calender
* create meeting
* create appointment
* create reminder
* create space
    * book/reserve space

