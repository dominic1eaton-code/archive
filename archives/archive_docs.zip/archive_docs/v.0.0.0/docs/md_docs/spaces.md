# spaces
# niguvu
* HQ building,campus
    - administration,management offices
    - subsidiary offices
    - meeting,conference offices
    - merger,acquisitions,partnership offices
        - legal offices
        - accounting,finance offices
        - construction, real estate development offices
        - media offices



# D.E. consulting
* consulting offices
* management,administration offices
* conference,meeting spaces



# bahari
* conference,meeting spaces
* system,software development offices
* management,administration offices
* shared workspaces


# obatala
* studios campus
* business/organization studio office spaces
* shared work spaces
* conference spaces
* management,administration offices


- studio cloud servers,data center
- individual studio developmental server rack(s)


# kanye
* investment office building(s)
* office spaces
* building server room,center
* management,administration offices


# sani
* institute campus
* research center buildings
* lab spaces
* education spaces, classrooms, conference rooms
* management,administration offices
- institute facility data center




* the factory, business accelerator workshop spaces
* the lab: business incubator (shared)work spaces 
* the workshop: (shared)maker spaces
    - textiles lab
    - computer/computing lab
    - 3d printing,digital fabrication lab
    - product prototyping,design,development lab
    - creatorspace shared coworking space lab



# jumuiya
* HQ office
* management,administration offices
* community development centers (franchise offices)
    * aka office
    * bakongo office
    * batwa office
    * dinka office
    * herero office
    * khoi office
    * nama office
    * san office
    * zulu office

# bemba technologies
* HQ office

# emchoro automation
* HQ office


# qamba
* software development office
* office space(s)

# moyo
* software development office
* office space(s)

# ossain
* software development office
* office space(s)

# kogi
* software development office
* office space(s)



# kokoro
* management,administration offices
* fabrication factory
* office space(s)
* production facilitiy(ies)


# nandi
* management,administration offices
* research,test facility(ies)
* office space(s)
* production facilitiy(ies)