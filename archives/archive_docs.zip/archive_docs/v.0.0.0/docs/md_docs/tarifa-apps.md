# Overview
firms, applications





# Emchoro
Software firm





# Obatala
Makerspace, business factory/studio(s)
skill development studio





# Ossain
Gaming and Simulation Studio Firm

## qala
SDE, software factory platform

* qala-package manager
* qala dev environment configurator

## Oru
Gaming platform

* ogun render engine
* oru game engine
* oru cad (parametric)
* oru 3d modeller (non parametric)

## Yota
Simulation platform

* yota procgen app
* yota mobility simulator






# Moyo
Enterprise application development firm

## Shango
business factory studio platform
business app factory/manager

## umuthi
kernel business app

## Ume
enterprise management system (large scale)
business management system (small scale)
- jobber, business operations system

## Chombo
design management system, standards management system, requirement management platform
entity management, compliance, risk management, legal
enterpise applcation architecture kernel
studio firm dashboard

## Pamoja
organization management platform

## Amanzi
finance, accounting platform

## Ina
CRM platform
marketing, sales, PR platform

## Moto
work management, operations platform

## Olumo
devops, IT, system configuration/provsision platform, SDE, software/tools factory
access control, system admin platform

## Tarifa
record, repository, registry management system
information systems, database management systems

## Mwezi
consulting management platform






# Oniru
Infrastructure and Manufacturing technology FIrm

## cheneo
space management platform
real estate management platform

## Imewe
automated fabrication platform

* imewe-3d printer
* imewe-cnc modeller

## Kituo
autonomous infrastructure, factory





# Nandi
Mobility Firm

## Nandi-X
mobility platform

* nandi-os
* nandi-network
* nandi-controller(s)
* nandi-commercial vehicle

## Amaya
mobility agent network platform

## Nzuki
Autonomous platooning platform




# Yemaya

## Osisi
automated plant propogation system 

## Ashe
^terraformata platform^
* agent theory




# D.E. LLC
software consulting


