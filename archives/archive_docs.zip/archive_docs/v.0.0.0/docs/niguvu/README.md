# niguvu
the board
governance organization build


## bemba
technology firm build



## jumuiya
community development firm build



## DE LLC
software consultancy firm build



## the eaton estate
personal estate management build


