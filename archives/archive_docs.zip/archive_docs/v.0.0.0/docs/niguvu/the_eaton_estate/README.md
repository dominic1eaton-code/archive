# the eaton estate
* personal affects
* assets, capital
* properties
* communes
* organizations
* businesses
* equity
* estate management
