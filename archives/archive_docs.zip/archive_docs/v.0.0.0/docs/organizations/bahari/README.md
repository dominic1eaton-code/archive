# Systems Engineering consulting and contracting firm

* organization
    * bahari consulting SBU
    * bahari contracting SBU

* clients
    * kogi
    * moyo
    * ossain
    * qamba
    * nandi
    * imewe

* contracts
    * dagba-kazi
    * umeOS
    * ochosi
    * qalaSF
    * nandi
    * imewe
