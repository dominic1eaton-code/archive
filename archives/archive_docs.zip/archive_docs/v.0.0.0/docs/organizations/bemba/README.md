# technology firm

* portfolio companies
    * kogi
    * moyo
    * ossain
    * qamba

