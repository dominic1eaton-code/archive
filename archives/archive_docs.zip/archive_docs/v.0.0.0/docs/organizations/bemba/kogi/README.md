# labor technology firm
* digital economy solutions


## products
* dagba-kazi digital labor platform


