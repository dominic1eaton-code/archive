# software tool development firm



## products
* qala software factory
    - new software solution management, administration, configuration