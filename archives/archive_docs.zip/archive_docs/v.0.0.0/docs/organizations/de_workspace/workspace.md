# personal projects portfolio
## personal
- books
    - army of one; no one is self made

- music
    - themes for instrumentalists

- programs
    - city-X international language cafe
    
- languages
    - french;creole haitian
    - german
    - spanish
    - portuguese
    - chinese
    - asl
    - levantine arabic
    - swahili
    - hindi
    - japanese

- family planning

- medical school

## open source projects
* document, knowledge management system



# estate portfolio
## organizations portfolio
* Eaton Family Estate LLC
* D.E. Software Engineering Consulting Firm LLC
* Bahari Systems Engineering Contracting Firm

## assets portfolio
* equity portfolio
    * eaton estate
        - wealth management portfolio
        - the Eaton foundation, endowment
    * D.E. software consulting
        - software consulting contracts
    * niguvu technology company inc
        - subsidiary management portfolio
        * kanye
            - investments
            - mergers,acquisitions,partnerships
        * sani
            - complex systems research projects
            - education programs
        * bahari
            - system application development contracts
        * obatala
            - business/organization studios
            * bemba
                * kogi
                * moyo
                * ossain
                * qamba
            * emchoro
                * nandi
                * kokoro
                * aganju
            * jumuiya
                * aka
                * bakongo
                * batwa
                * dinka
                * herero
                * khoi
                * nama
                * san
                * zulu