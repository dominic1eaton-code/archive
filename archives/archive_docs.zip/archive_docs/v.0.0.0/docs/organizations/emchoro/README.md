# automation firm

* portfolio companies
    * nandi
    * kokoro