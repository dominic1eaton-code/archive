# aganju company 
* autonomous environment, plant propogation, sustainability solutions
* autonomous agriculture solutions
