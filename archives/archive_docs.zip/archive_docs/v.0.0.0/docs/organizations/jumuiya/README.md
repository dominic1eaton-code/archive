# community development firm
jumuiya inc
the jumuiya urban development organization


* urban tech cities program
* urban community development center cities program
    - community center medical EHR system
* urban housing project renovation program
* urban renewal program
* urban community development program
* urban tech pipelines program
* urban cooperative organizations development
    - equity crowd funding models


- projects
    - urban memorial markers program
        - emmit till marker
        - igbos landing marker
        - tulsa riot marker
        - goerge floyd marker
        - marker X

- community legal assistance management
- (community,community individual) IP,copyright,watermark,trademark,patent management and protection management
    - patented include new and useful processes, machines, manufactures, or compositions of matter. These can also include new and useful improvements to existing invention
    - media,text,voice over,image,likeness,etc... IP protection, moral rights, rights to publicity, forensic digital watermark

- urban housing cooperatives program
