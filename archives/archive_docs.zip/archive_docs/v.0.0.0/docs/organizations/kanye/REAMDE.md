# kanye investments firm
* wealth management
* investment management
* portfolio management
* capital management
* asset management
* fund management
- venture capital (fund)