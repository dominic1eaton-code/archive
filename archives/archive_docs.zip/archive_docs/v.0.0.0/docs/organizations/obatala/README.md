# obatala venture capital investments firm
* business model
    - funding model
        - membership dues, subscription fees, equity fees, service fees, content creation fees
        - series funding
        - crowdfunding
        - donors,sponsors,grants
        - private equity investors
    - services
        - create,incubate,accelerate,maintain,support organizations at various lifecycle stages
        - holistic urban,diverse entreprenuerial organization support and development services
        - organization development training,learning,hackathons,networking events,development workshops,tech events
        - idea workshopping,development,development,counseling services
            - convert ideas into minimal viable organizations MVOs

* organization SBUs
    * vc fund
        - VC private equity fund
        - VC organization investment portfolio management
    * vc lab
        - organization incubator
    * vc factory
        - organization accelerator
    * vc workshop
        - organization idea workshop
        - entreprenuer workshop
        - business development workshop
        - workshop events,training,learning
    * VC community space
        - gethering spot
        - event space
        - restaurant+bar
        - coworking space
        - networking space
    * vc studio
        - OpCo studio portfolios
        - organization builder,creator,developer
        - early business studios
        - organization (type-X) studio
        - business (type-X) studio
        - technology studio
        - software studio
        - finance studio
        - marketing studio
        - design studio
        - research studio
        - non profit studio
        - operations studio
        - management studio
        - mobility studio
        - manufacturing studio
        - consulting studio
        - misc. studio...


* vc fund portfolios; (startup) business studios
    * D.E software consulting firm
        - software and technology consulting firm
    * niguvu
        - holding company
        - board services
    * bahari
        - software development contracting services
    * sani
        - research and development projects,products, services
        - academic education programming services
        - vocation training, bootcamp, tech career guidance, entreprenuerial career guidance and consulting services
        - makerspace
    * kanye
        - brokerage management services
        - investment,portfolio,capital management services
        - wealth management services
    * bemba
        * kogi
            - personal development,productivity tools
            - personal project portfolio management system
        * moyo
            - digital organization transformation and management products and services
            - digital organizationOS system deployment,management,maintainence
        * ossain
            - simulation development solutions,products,services
        * qamba
            - software production and development environment products,services
    * emchoro
        * nandi
            - mobility solutions
        * kokoro
            - digital manufacturing solutions
        * aganju
            - digital agriculture,horticulture development products,services
    * jumuiya
        - cooperative organization development services
        - community development and support services
        - community development,management solutions
        * aka
        * bakongo
        * batwa
        * dinka
        * herero
        * khoi
        * nama
        * san
        * zulu

* products
    * ume
    * ochosi
    * qala
    * nandi
    * imewe
    * dagba-kazi
    * mizizi-miji
    * osisi



* networking,projects,social media
- social media
    * tiktok page
    * facebook page
    * X page
    * linkedin page
    * instagram page
    * youtube page
    * indeed page
    * glassdoor page
    * zip recruiter page
    * patreon pages
    * kickstarter pages
    * upstart engine pages
    * gofundme page
    * change.org pages
    * upwork page
    * fiverr page
    * taskrabbit page
    * meetup page
    * eventbrite page
    * slack pages
    * discord pages
    * reddit pages
    * medium pages
    * quora pages
    * stackoverflow pages
    * public github org
    **kazi page**
- projects
    - urban tech podcast
        - urban tech news
        - urban tech interviews
        - urban tech lifestyle
        - urban tech talks, panels
        - urban tech IP,patent talk, audit
        - urban tech domain+career+job talks (EHR, automotive, AV, AI-machine learning)
        - urban tech education
    - urban tech career development,learning
    - software product (video) guides
    - diversity in tech memorial museum(s) program
- events, event circuit calendar
    - diversity in tech week conference
    - urban tech week conference
    - urban tech mixers
    - urban tech meetups
    - urban tech content creators summit
    - urban youth tech day programs
    - urban tech vc studio,makerspace open houses
    - urban tech hackathon
    - vc studio,factory,lab,workshop events, meetups
        - vc studio mixer
        - vc factory workshops
        - vc workshop,lab openhouse
        - vc studio open house
        - vc studio,lab coffee and code
        - vc-X meetups
        - vc-X networking events
        - vc-X marketing,advertising events
        - vc-X showcase events
        - queer tech meetups
        - diverse tech meetups
        - urban tech talks
            - tech panels, speakers
            - q&a sessions
            - speeches

- the urban tech cooperative

