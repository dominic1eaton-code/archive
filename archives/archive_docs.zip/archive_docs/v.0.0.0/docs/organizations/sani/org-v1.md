# the sani research institute; the sani institute of technology
* the institute for systems science and engineering
    * the sani endowment fund
    * the center for autonomous systems
        * the department of autonomous mobility systems
            * the autonomous vehicles program
                * the autonomous EV lab
                    * the autonomous sedan project
                    * the autonomous van project
                    * the autonomous bus project
    * the center for digital fabrication
        * department of 3D printing
            * filament printer program
                * standard filament printing series lab
                    * medium size standard filament printer project
            * resin printer program
        * department of laser printing
        * department of CNC machining
    * the center for computer simulation
        * vehicle,tranportation mobility netowrks simulation project
        * physics,dynamics,fluid simulation project
        * procedural generation project
    * the center for enterprise engineering
        * organization design and development department
        * organization engineering department
            * organization newtorks,infrastructure,cloud system development lab
    * the center for urban development
        * urban development solutions lab
        * urban community development project
    * the center for technology education and entreprenuership
        * adult,youth technology education program
        * the workshop: the sani creator space program; prototype/idea workshop 
        * the factory: the sani organization/business accelerator
        * the lab: the sani organization/business incubator