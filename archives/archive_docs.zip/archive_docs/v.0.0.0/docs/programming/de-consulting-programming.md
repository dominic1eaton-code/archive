# D.E. Software consulting company progamming
software consulting services


## organization
* founder, principle, C-suite
* partners
    * senior, mid-level, jr
* project managers
* consultants, analysts, technicians
* support, office, administrative staff
    * marketing, sales, accounting, finance, office management, sanitation specialists, HR generalists/specialists

* stakeholders
    * consultation clients


## Client programming


## Consulting services
* data analytics
* strategy planning and development

