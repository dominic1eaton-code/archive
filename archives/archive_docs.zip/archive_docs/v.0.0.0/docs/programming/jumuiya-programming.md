# Jumuiya organization programming
NPO programming




## Batwa
### Community Development center program
* decentralized organization management program
    * case management program
        * community case, individual case, organization case management system
        * social services program
        * living essential services program
        * greenspace management program
        * financial services program
        * education services program
        * community pipelines program
        * community event management program


## Khoi
### Urban Youth technology afterschool program
* youth makerspace, fablab, hackerspace, technology lab project

### Urban technology vocation program
* urban coding bootcamp program

### Prison technology education programming
* prison technology classes programming

### Prison and urban entreprenuership program
* urban and prison VC studio, accelerator, incubator program
* urban employment and staffing agency program




## Herero
### Urban and Prison behavioral health services program
* drug rehabilitation and treatment services
* behavioral health services
* case management 
    * case manager, sponsor, client
    * data gathering
    * treatment plans
    * diagnosis
    * emergency support
    * therapy services

### Urban and prison group therapy, mental health therapy, trauma therapy progam
* group therapy services
* individual therapy services




## Igbo
### The Maafa memorial program
Project
* maafa memorial site
    * the halls of the Maafa
        * nameplates of victims
        * memorial statues
        * memorial gardens
        * undergound halls
    * musuem project

Sites
* Maafa program MO
    * the maafa project STL
    * the maafa project KC
 
### BLM memorial sites program
* memorial statues
* memorial markers
* memorial greenspaces


### Civil rights leaders memorial greenspace statues program
* annie tunbo malone
* homer g phillips
* harriet tubman


### The urban family lineage program, project


## Nama
### Urban poverty reformation program
* nightlife living essentials program
* housing and neighborhood funding, renovation, restoration, maintainence program



## Aka
### Greenspace development program
* urban community gardens project
* reforestation project
* urban closed loop green construction program
* forestry management program
    * social forestry project





## Zulu
### Financial and wealth development and management program
* the freedmans's urban credit union program
* urban grant and loan program
    * housing grant program
    * business grant program
    * NPO grant program
    * education grant program
    * greenspace grant program
* the maafa fund
    * urban compensation dispensation program


