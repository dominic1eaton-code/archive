# kanye investments firms

* equity investments
* real estate investments
* PE, venture capital investments
* NPO, research investments


## org investments
* construction company investment
* outsourcing company-X investment