# the iri project
## iri I
<beginning> capsule shoots from rock mountain side and rapidly deploys through air, until landing on a pathway, which it begins sliding down a rocky slope. capsule contains player-agent-A, is controlled by agent. player navigates capsule down path, avoiding obstacles. Flashes of light and boistorous sounds outline a large structure in the distance. capsule is sliding down pathway slope into a large crevice, where a large egg like metallic structure sits lodged in center of crevice. Bolts of lightening strike the sides of the wide crevice-hole-aperture showing the massiveness of the metal-egg like structure. The skies are pitch black with the only light coming from the continuous lightening flashes. player continous to navigate rapidly sliding capsule down spiraling pathway until capsule hits and slides of large ramp like rock, propelling the capsule into one of several wide cracked openings in the metal-egg structure. Player capsule enters egg-crack moving through an dark, increasingly narrowing corridor until finally entering a small series of tunnels, which then lead to holes. Once player-capsule navigates through tunnels, still having fast continuous forward momentum, player shoots out of small tunnel opening and falls/plummets into a vast cavern like room, finally crashing into the ground floor of large room-cavern. capsule opens and player-agent-A emerges and begins to move around and have the ability to take various actions.<begin act I>


- player is black robot like character, with no markings
- as game play continous, more player actions become available
- as player levels up, markings increasingly begin to appear on player character's outer exterior
- single switchable player play


## iri II
- team based tactics player play


## iri III

long ago [pause] our people were at war...
    <cut to epic war battle scene>
    <heavy war afrobeats music>

we fought for glory, honor and blood. We fought while the world around us slowly decayed into oblivion. We sought to end our woes. We sought to become gods

    <african choir of aahs starts low. Slowly increases to dramatic aahs with ritualistic shrieks and shouts>

Our only refuge, our salvation, appeared one day in the form of a seed, that would give us the answers we had spent so long searching for, and be our guiding force to eternity...

