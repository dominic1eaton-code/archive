# digital fabrication platform
- automated digital fabrication platform
    - automated digital fabrication ERP management system
    - automated digital fabrication farm system