# mizizi e-governance,cooperative management system platform
- urban community development management platform
- cooperative management platform
- e-government platform


## application modules, core features
* community profile, digital space
* community network
* community governance
    - organizing,voting,policies,etc... management
    - portable benefits management
* community case management
* online petition platform
* digital voting management plaform
* multigenerational portable benefits management
    * estate,weatlh,asset,capital management
    * investment, portfolio management
    * tax planning
    * insurance management

