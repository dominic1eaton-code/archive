# simulation development environment
- simulation management system
- simulation SDK
- simulation package manager
- simulation,scenario digital workspace, configuration manager
- simulation editor,creator,lifecycle management
- simulation deploy,release,share ecosystem