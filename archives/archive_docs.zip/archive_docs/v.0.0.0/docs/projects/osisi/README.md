#
- automated plant propogation system
- automated agriculture management system
