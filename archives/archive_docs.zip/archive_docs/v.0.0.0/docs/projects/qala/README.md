# software factory
- software development environment
- software package manager
- software license,IP,trademark manager
- software factory cloud, data center