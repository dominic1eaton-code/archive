# Dewo communcations app
- voice app
- message chat app
- video app
- email app

target platform clients
- desktop app
- web app
- mobile app
    - IOS app
    - android app