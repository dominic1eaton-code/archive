# python test sandbox
algorithm development
fluid simulation tests
procedural generation
ml ai algorithm tests