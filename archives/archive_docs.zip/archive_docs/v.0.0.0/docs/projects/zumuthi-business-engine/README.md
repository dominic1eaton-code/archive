# overview
Ume organization management platform

# kernel render engine
* [ ] feature/kernel
* [ ] feature/kernel_web_app_client
* [ ] feature/kernel_server
* [ ] feature/kernel_database
* [ ] feature/kernel_android_app_client
* [ ] feature/kernel_ios_app_client
* [ ] feature/kernel_desktop_app_client
* [ ] feature/kernel_application_studio_management
* [ ] feature/kernel_application_entity_management
* [ ] feature/kernel_application_organization_management
* [ ] feature/kernel_application_resource_management
* [ ] feature/kernel_application_work_management
* [ ] feature/kernel_application_client_management
* [ ] feature/kernel_application_infrastructure_management
* [ ] feature/kernel_optimization
* [ ] feature/kernel_benchmarking
* [ ] feature/kernel_unittest
* [ ] feature/kernel_architecture
* [ ] tags/kernel_release_1.0.0
* [ ] release/1.0.0

* kernel rewrite, engine module breakup
    * tags/kernel_release_1.1.0
    * release/2.0.0


## umuthi
* tags/kernel_release_1.1.0
* release/2.0.0

## chombo
* tags/kernel_release_1.1.0
* release/2.0.0

## pamoja
* tags/kernel_release_1.1.0
* release/2.0.0

## amanzi
* tags/kernel_release_1.1.0
* release/2.0.0

## moto
* tags/kernel_release_1.1.0
* release/2.0.0

## shango
* tags/kernel_release_1.1.0
* release/2.0.0

## olumo
* tags/kernel_release_1.1.0
* release/2.0.0
