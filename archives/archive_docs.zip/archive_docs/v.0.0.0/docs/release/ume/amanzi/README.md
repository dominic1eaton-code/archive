# features

- create ledger
- create journal
- create transaction
- create balance


- debit account
- credit account


* track equity
* track cash(flow)
* track debt
* track taxes
* track burn rates
* track CAPEX,OPEX


- bookkeeping system
    - track income,expenses,assets,liabilities,equity
- payroll system
- cash book
- financial policy manager
- cash flow modelling,forecasting
- change request management
- chart of accounts
- financial reporting,monitoring,analysis,management
- equity management system, capitalization table management system

