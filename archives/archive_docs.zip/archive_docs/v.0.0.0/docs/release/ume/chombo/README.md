# features
- entity organization document,artifact registry management
- entity document generator
- entity configuration management
- entity views
    - single entity dashboard, portal, profile
    - entites dashboard, portal, profile
    - multi entity tiles view
- entity view,list,search,filter




- create,add entity
    - create default entity artifact,document registry
    - create entity charter
        - create entity mission,vision,strategies,big rocks
    - onboard entity info
        - name
        - ID
        - entity type
            - sole proprietorship,LLC,GP,LP,LLP,SCorp,CCorp
        - firm type
            - technology firm, investment firm, software firm, etc...
        - EIN
        - location
        - registered agent, founders, owners, principles, stakeholders, teams, organization
        - tags, categories
        - creation,established date
    - create licenses, trademarks, watermarks, copyrights, IP
    - create entity portfolio
        - create projects, programs, products, services
    - create entity organization
    - track entity lifecycle
        - established,development,decline,disssolution,exit,merge,acquisition; entity state/status change(s)
    - change entity configuration,settings; entity reference/master data update(s)




- generate document
    - generate contract
    - generate agreement
    - generate plan


    
- entity (investment) tracking, monitoring, reporting, analytics



