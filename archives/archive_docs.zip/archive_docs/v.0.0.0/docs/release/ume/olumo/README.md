# features
- organization infrastructure catalogue
    - search,view,list organization physical devices,networks,servers,end points,etc...
    - organization infrastructure status,monitoring,reporting,alert messages,notifications


