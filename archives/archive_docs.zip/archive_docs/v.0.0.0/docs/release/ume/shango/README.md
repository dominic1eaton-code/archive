# features

- create client
- create lead
- create order
- create invoice
- create sale
- create reciept




- track customer
- track advertising data
    - generate advertising ID
- track marketing data
    - track marketing channels




- sales data forecasting,analysis,reporting,monitoring
- marketing data forecasting,analysis,reporting,monitoring



