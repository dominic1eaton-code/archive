# features
- create organization kernel
    - create organization space
    - create organization registry
    - create organization repository
    - create organization administrator(s)
    - create organization datastructures
        - organization scalable spreadsheet
        - organization database
        - organization data sheet
    - create organization structure,infrastructure definitions
    - create organization default accounts,identity+access models

- create account
    - create administrator
    - create user
        - name
        - email
        - password
        - api token(s)
        - ssh token(s)
        - pin code(s)
        - access flags





