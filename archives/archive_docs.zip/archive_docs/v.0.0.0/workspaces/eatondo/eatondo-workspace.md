# personal projects portfolio
## personal
- books
    - don't get money, get equity
    - army of one
    - hobby interest books
        - a book of languages
        - a book of music
        - a book of dance

- publications
    - agent theory: the foundation of systems
        - complex systems science and engineering
        - game theory,economics
        - simulation theory
        - statistical mechanics, thermodynamic systems
        - distributed autonomous systems theory
        - mathematical control,optimization
        - stochastics,probability theory
        - ml-ai,statistical inference,statistical learning theory
        - information theory, language theory
        - observation,perception theory
    - complex systems science and engineering
    - enterprise engineering
        - software defined organizations, minimal viable organizations MVO design
    - simulation engineering
        - world procedural generation
    - autonomous mobility systems
        - the AV crowd (project), AV platooning

- music
    - themes for instrumentalists

- programs
    - city-X international language cafe
    
- languages
    - french;creole haitian
    - german
    - spanish
    - portuguese
    - chinese
    - asl
    - levantine arabic
    - swahili
    - hindi
    - japanese

- family planning

- medical school

## open source projects
* document, knowledge management system



# estate portfolio
## organizations portfolio
* Eaton Family Estate LLC
* D.E. Software Engineering Contracting and Consulting Firm LLC; DBA Bahari Systems Engineering Firm

## assets portfolio
* equity portfolio
    * eaton estate
    * bahari
    * niguvu technology company inc./LLC7
        * kanye
        * sani
        * obatala
            * bemba
                * kogi
                * moyo
                * ossain
                * qamba
            * emchoro
                * nandi
                * kokoro
            * jumuiya
                * aka
                * bakongo
                * batwa
                * dinka
                * herero
                * khoi
                * nama
                * san
                * zulu


- the stl language society, non profit
    - stl language cafe
    - stl language meetups, events
    - stl cultural events