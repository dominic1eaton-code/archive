# venture capital investments firm

* organization
    * vc fund
    * vc studio
    * vc lab
    * vc factory
    * vc workshop

* vc fund portfolios
    * niguvu
    * bahari
    * sani
    * kanye
    * bemba
        * kogi
            - dagba-kazi C2C digital labor platform
        * moyo
            - ume organization operating systeminu
        * ossain
            - ochosi systems/simulation development platform
        * qamba
            - qala systems/software development factory
    * emchoro
        * nandi
            - nandi mobility platform
        * kokoro
            - imewe digital fabrication system
    * jumuiya
        - mizizi-miji urban community development and management platform
        * aka
        * bakongo
        * batwa
        * dinka
        * herero
        * khoi
        * nama
        * san
        * zulu

* products
    * ume - rust kernel
    * mizizi-miji - rust kernel
    * dagba-kazi - zig kernel
    * osisi - zig kernel
    * qala - cpp kernel
    * ochosi - cpp kernel
    * nandi - c kernel
    * imewe - c kernel
